-- List of shell types

CREATE TYPE scalar8;
CREATE TYPE sphere_vector;
CREATE TYPE sphere_halfvec;
CREATE TYPE sphere_scalar8;
