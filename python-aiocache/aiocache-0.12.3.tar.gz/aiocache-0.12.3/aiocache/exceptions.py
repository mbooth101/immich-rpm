class InvalidCacheType(Exception):
    pass
