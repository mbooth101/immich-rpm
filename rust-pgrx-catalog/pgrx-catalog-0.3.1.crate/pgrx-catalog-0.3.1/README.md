# pgrx-catalog

An out-of-tree version of pgrx catalog safe bindings.

See https://github.com/pgcentralfoundation/pgrx/pull/1545.
