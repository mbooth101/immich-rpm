=========
OmegaConf
=========

Overview
^^^^^^^^
OmegaConf is a YAML based hierarchical configuration system, with support for merging configurations from multiple sources (files, CLI argument, environment variables)
providing a consistent API regardless of how the configuration was created.
OmegaConf also offers runtime type safety via Structured Configs.

.. toctree::
   :maxdepth: 2

   usage
   tuple_migration
   custom_resolvers
   structured_config
   grammar
   how_to_guides
   yaml_aliases
   api_reference



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
