### Setup development

#### Essentials

Use a repo-local virtual environment in `.venv`.

Create the environment:

```bash
python3 -m venv .venv
```

Activate it:

```bash
source .venv/bin/activate
```

Install development dependencies:

```bash
python -m pip install --upgrade pip setuptools
python -m pip install -r requirements/dev.txt -e .
```

The optional `omegaconf-pydevd` debugger plugin lives in
`subprojects/omegaconf-pydevd/` and has its own packaging and tests.

Optionally install commit hooks: `pre-commit install`

pre-commit will verify your code lints cleanly when you commit. You can use `git commit -n` to skip the pre-commit hook for a specific commit.

##### Mac
OmegaConf is compatible with Python 3.8 and newer.

One way to install multiple Python versions on Mac is to use pyenv.
The instructions [here](https://github.com/GoogleCloudPlatform/python-docs-samples/blob/master/MAC_SETUP.md)
will provide full details. It shows how to use pyenv on Mac to install multiple versions of Python and have
pyenv make specific versions available in specific directories automatically.
After selecting the Python version for this checkout, create `.venv` with that interpreter.

#### Testing
Run tests directly with `pytest`.

Run all CI tests with nox:

```
$ nox -l
Sessions defined in /home/omry/dev/omegaconf/noxfile.py:
* omegaconf-3.10
* docs
* coverage-3.10
* lint-3.10
* test_jupyter_notebook-3.10
```

To run a specific session use `-s`, for example `nox -s lint` will run linting.

OmegaConf uses Ruff for formatting, linting, and import sorting. Run
`ruff format .` to format code and `ruff check .` to lint it. Use
`ruff check --fix .` to apply import-sorting fixes.

To build the docs execute `nox -s docs` or `make`(inside docs folder). Make gives you different options, for example, you can build the docs as html files with `make html`. Once the docs are built you can open `index.html` in the build directory to view the generated docs with your browser.

For the Docusaurus website, follow [the website checks](website/README.md#example-and-api-checks)
to execute selected Markdown examples and check generated API snapshots.
Run current examples against the editable checkout and stable examples in a
separate OmegaConf 2.3.1 environment. Both version checks must pass before
the website can build and deploy in CI.

#### Submitting a PR

We welcome your pull requests.

When submitting a PR please ensure that it includes:
- automated tests for any new feature or bugfix
- documentation for any user-facing change
- a one-line news fragment under the `news` folder for any non-trivial
  user-visible change. Use the issue or pull request number as the filename,
  with one of these extensions: `.feature`, `.bugfix`, `.api_change`, `.docs`,
  `.misc` (for example, `news/1234.bugfix`).

Developer-only tooling, repository maintenance, and CI-only changes do not need
a news fragment unless they affect the shipped product experience.

For any non-trivial change, please open an issue or design discussion and wait
for maintainer feedback before starting substantial implementation work. Pull
requests in these areas should link to the issue or discussion where the
direction was agreed. Pull requests without prior design alignment may be
redirected to discussion before implementation review.

#### Modifying the Jupyter notebook

In order to change the Jupyter notebook you first need to open it with `jupyter notebook`.
Change the cell you want and then, execute it so the expected output is shown.
Note that the output after you execute the cell is saved as expected ouput for further
testing.

In case that the in[number] of cells aren't in order you should go to the
kernel in the toolbar and restart it.

#### Releasing a version

OmegaConf uses GitHub Actions with PyPI Trusted Publishers for automated releases.

**Prerequisites (one-time setup):**
1. Configure Trusted Publisher on PyPI (project maintainers only):
   - Go to https://pypi.org/manage/project/omegaconf/settings/publishing/
   - Add GitHub as a trusted publisher with:
     - Owner: `hydra-ecosystem`
     - Repository name: `omegaconf`
     - Workflow name: `publish.yml`
     - Environment name: `pypi-publish`
   - Repeat for the `omegaconf-pydevd` PyPI project; the workflow publishes
     both packages.

2. Configure Trusted Publisher for dev releases on PyPI (project maintainers only):
   - Add GitHub as a trusted publisher with:
     - Owner: `hydra-ecosystem`
     - Repository name: `omegaconf`
     - Workflow name: `publish_dev.yml`
     - Environment name: `pypi-publish-dev`
   - Repeat for the `omegaconf-pydevd` PyPI project; the workflow publishes
     both packages.

3. Configure the `pypi-publish` environment in GitHub repository settings:
   - Require maintainer approval before publishing.
   - Allow the stable release branches, such as `2.4_branch`.
   - If self-review is disabled, a different authorized maintainer must approve
     the run, or an administrator must explicitly bypass the protection.

4. Create the `pypi-publish-dev` environment in GitHub repository settings:
   - Allow publishing from the development branch you use for dev releases
     (for example `main`) and from any RC tags you will publish from
     (for example `v2.4.0rc1`)
   - Add protection rules (e.g., require manual approval)

**Official release process:**
1. Bump the version with `bump-my-version`, for example:
   - `bump-my-version bump patch`
   - `bump-my-version bump minor`
   - `bump-my-version bump --new-version X.Y.Z`
2. Update `NEWS.md` with release notes (use `towncrier build --version X.Y.Z`
   to assemble the notes and consume the news fragments)
   In a Sapling checkout, render with `towncrier build --draft --version X.Y.Z`
   and prepend the resulting entry to `NEWS.md`, then remove the consumed
   fragments with `sl remove`. Towncrier's automatic staging and fragment
   removal do not support Sapling.
3. Commit the release preparation on `main`, validate it, then merge it into
   the stable release branch (for example `2.4_branch`). Preserve the existing
   branch history. While `main` carries only fixes for that stable series,
   continue merging fixes into the stable branch. Once new features begin on
   `main`, backport only appropriate fixes.
4. Ensure the release branch includes the current `publish.yml` workflow and
   its `build_helpers/release_workflow.py` helper. Start **Publish to PyPI** in
   GitHub Actions, choosing the prepared stable branch and expected version:

   ```bash
   gh workflow run publish.yml --ref 2.4_branch -f version=2.4.0
   ```

   Every job uses the exact commit selected at dispatch. Preparation verifies
   both source versions and checks that neither target version is already on
   PyPI. The run summary shows the latest published version on the selected
   release line for each package, including dev and release-candidate versions.
   It builds, verifies, and smoke-installs the artifacts, then creates a draft
   GitHub Release and tag. The draft notes come from the matching `NEWS.md`
   entry; older release entries are excluded.
5. Review the run summary, artifacts, and draft GitHub Release, then approve
   the `pypi-publish` environment. This uploads both packages. The workflow
   checks their filenames and SHA-256 digests on PyPI before publishing the
   draft GitHub Release. Publishing a GitHub Release manually does not start
   another PyPI upload.

Preparation runs before approval. Do not approve until the artifacts and draft
are ready. Artifacts and recovery state are retained for seven days; approve or
recover within that period. For a pre-release, follow the separate development
release process below.

GitHub Release operations use the built-in `GITHUB_TOKEN`. The release commit's
entire `.github/workflows/` tree must match the default branch; preparation and
the approved upload job check this. If they differ before any PyPI upload,
synchronize all workflow files onto the release branch and restart preparation
from that new commit. The default branch can still change after the last check.
If anything already reached PyPI, preserve the release commit/tag and finish
GitHub publication manually rather than retagging or uploading the version again.

**Failure recovery:**

- If upload fails and repeated PyPI checks confirm no artifacts were published,
  the workflow removes its draft and any tag it created. A pre-existing tag is
  preserved. Start a fresh workflow run after addressing the failure.
- Partial publication, digest mismatches, or an unavailable PyPI API preserve
  the draft, tag, and retained artifacts for manual recovery. No PyPI files are
  deleted. Do not start a fresh prepare run for an already-published version.
- If both packages reached PyPI but publishing the GitHub Release fails, use
  **Re-run failed jobs**. GitHub publication is a separate job; it verifies the
  existing uploads and publishes the existing draft without uploading again.
  This step is also safe to retry if the first API response was lost.
- Preparation failures or cancellations may leave a tag or draft. Inspect the
  retained `release-bundle/state.json` and external state before manual cleanup.
  Automated cleanup refuses to delete a published release or a draft/tag changed
  since preparation, including changes to the draft name, target commit, notes,
  prerelease state, or added assets. These checks reject edits observed before
  deletion. GitHub provides no atomic conditional DELETE, so avoid editing or
  publishing the draft or changing the tag while a run is active; an intervening
  maintainer change can still be deleted.

The release workflows handle:
- Installing Java (required for ANTLR parser generation)
- Building source distribution and wheel for both `omegaconf` and
  `omegaconf-pydevd`
- Verifying artifacts for both packages with `twine check`
- Publishing to PyPI via Trusted Publishers (no API tokens needed)

**Development release process:**
The separate, manually triggered `publish_dev.yml` workflow can publish
pre-release or development package versions to PyPI. It does not run when a
GitHub pre-release is published.

For a release candidate such as `2.4.0rc1`, assemble `NEWS.md` with
`towncrier build --version X.Y.ZrcN --keep` to retain the news fragments until
the final stable release. Use that release entry for the GitHub pre-release
notes. The stable `publish.yml` workflow accepts only final `X.Y.Z` versions.

1. Commit and push the version and release notes.
2. Create a GitHub pre-release tagged from that commit (for example,
   `v2.4.0rc1`).
3. Run the `Publish dev release to PyPI` workflow from that tag in GitHub
   Actions, or run `gh workflow run publish_dev.yml --ref v2.4.0rc1`.
4. Approve the `pypi-publish-dev` environment if required.
5. If preparing another development release or RC, advance the prerelease
   number with `bump-my-version bump pre_n`.
6. Commit and push the version bump.

**Manual release (fallback):**
If you need to publish manually:
```bash
rm -rf dist/ omegaconf.egg-info/
python -m build
python -m build subprojects/omegaconf-pydevd
twine check dist/* subprojects/omegaconf-pydevd/dist/*
twine upload dist/* subprojects/omegaconf-pydevd/dist/*
```
