---
id: intro
slug: /
title: OmegaConf Next
description: Start with OmegaConf development documentation.
---

These are the development documentation, currently based on OmegaConf 2.4.0.
Use the [stable 2.4 documentation](/docs/) for the released version, or the
[previous 2.3 documentation](/docs/2.3/).

OmegaConf turns Python data, YAML, and overrides into a consistent
configuration API.

## Start here

- [Install OmegaConf](./get-started/install) gets the stable release into
  your Python environment.
- [Your first config](./get-started/first-config) walks through creation,
  string interpolation, and merging.

## Explore the main capabilities

1. [Work with configs](./concepts/configs-and-values): learn containers,
   [mandatory missing values](./concepts/missing-values), merging, and
   serialization.
2. [Interpolation and resolvers](./concepts/interpolation): start with node
   and string interpolation, then [resolver interpolation](./concepts/resolvers).
3. [Structured configs](./concepts/structured-configs): declare typed fields, learn
   [field types](./concepts/field-types), then
   [optional fields](./concepts/optional-fields) and validation.

Each section also contains task pages you can use as needed. For exact
signatures and options, use the [Python API](./reference/python-api) and its
[generated symbol details](./reference/python-api/omegaconf).
