# pgrx-pg-config

A crate containing an abstraction/wrapper over Postgres' `pg_config` to be used with [`pgrx`](https://crates.io/crates/pgrx/)
