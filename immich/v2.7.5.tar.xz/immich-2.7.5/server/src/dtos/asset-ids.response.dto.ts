import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ValidateUUID } from 'src/validation';

/** @deprecated Use `BulkIdResponseDto` instead */
export enum AssetIdErrorReason {
  DUPLICATE = 'duplicate',
  NO_PERMISSION = 'no_permission',
  NOT_FOUND = 'not_found',
}

/** @deprecated Use `BulkIdResponseDto` instead */
export class AssetIdsResponseDto {
  @ApiProperty({ description: 'Asset ID' })
  assetId!: string;
  @ApiProperty({ description: 'Whether operation succeeded' })
  success!: boolean;
  @ApiPropertyOptional({ description: 'Error reason if failed', enum: AssetIdErrorReason })
  error?: AssetIdErrorReason;
}

export enum BulkIdErrorReason {
  DUPLICATE = 'duplicate',
  NO_PERMISSION = 'no_permission',
  NOT_FOUND = 'not_found',
  UNKNOWN = 'unknown',
  VALIDATION = 'validation',
}

export class BulkIdsDto {
  @ValidateUUID({ each: true, description: 'IDs to process' })
  ids!: string[];
}

export class BulkIdResponseDto {
  @ApiProperty({ description: 'ID' })
  id!: string;
  @ApiProperty({ description: 'Whether operation succeeded' })
  success!: boolean;
  @ApiPropertyOptional({ description: 'Error reason if failed', enum: BulkIdErrorReason })
  error?: BulkIdErrorReason;
  errorMessage?: string;
}
