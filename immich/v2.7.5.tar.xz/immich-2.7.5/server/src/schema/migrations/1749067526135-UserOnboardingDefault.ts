import { Kysely, sql } from 'kysely';
import { UserMetadataKey } from 'src/enum';

export async function up(db: Kysely<any>): Promise<void> {
  await sql`INSERT INTO user_metadata SELECT id, ${UserMetadataKey.Onboarding}, '{"isOnboarded": true}' FROM users
    ON CONFLICT ("userId", key) DO NOTHING
  `.execute(db);
}

export async function down(db: Kysely<any>): Promise<void> {
  await sql`DELETE FROM user_metadata WHERE key = ${UserMetadataKey.Onboarding}`.execute(db);
}
