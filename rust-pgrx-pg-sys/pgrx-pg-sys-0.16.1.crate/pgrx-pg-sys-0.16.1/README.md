# pgrx-pg-sys

Bindgen-generated bindings for [`pgrx`](https://crates.io/crates/pgrx/).  Not meant to be used on its own.
