skbuild.platform\_specifics package
===================================

.. automodule:: skbuild.platform_specifics
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

skbuild.platform\_specifics.abstract module
-------------------------------------------

.. automodule:: skbuild.platform_specifics.abstract
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.bsd module
--------------------------------------

.. automodule:: skbuild.platform_specifics.bsd
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.cygwin module
-----------------------------------------

.. automodule:: skbuild.platform_specifics.cygwin
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.linux module
----------------------------------------

.. automodule:: skbuild.platform_specifics.linux
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.osx module
--------------------------------------

.. automodule:: skbuild.platform_specifics.osx
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.aix module
----------------------------------------

.. automodule:: skbuild.platform_specifics.aix
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.platform\_factory module
----------------------------------------------------

.. automodule:: skbuild.platform_specifics.platform_factory
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.unix module
---------------------------------------

.. automodule:: skbuild.platform_specifics.unix
   :members:
   :undoc-members:
   :show-inheritance:

skbuild.platform\_specifics.windows module
------------------------------------------

.. automodule:: skbuild.platform_specifics.windows
   :members:
   :undoc-members:
   :show-inheritance:
