from __future__ import annotations


def hello(msg):
    print(msg)
