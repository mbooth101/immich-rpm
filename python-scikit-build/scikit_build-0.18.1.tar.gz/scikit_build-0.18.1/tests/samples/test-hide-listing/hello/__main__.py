from __future__ import annotations

if __name__ == "__main__":
    from . import hello

    hello.hello("World")
