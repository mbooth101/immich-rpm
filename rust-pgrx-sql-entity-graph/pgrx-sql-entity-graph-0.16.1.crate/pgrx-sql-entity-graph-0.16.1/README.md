# pgrx-sql-entity-graph

Sql Entity Graph generation for [`pgrx`](https://crates.io/crates/pgrx/).

This crate is used internally by various `pgrx` crates